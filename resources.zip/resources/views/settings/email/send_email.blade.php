<html>
<head>

    <title></title>
</head>
<body>

{!!$data !!}

</body>
</html>





