<footer class="footer"> © 2020-<?php echo date('Y'); ?> Emart. All rights reserved.</footer>


